<?php
// This file is part of Moodle - http://moodle.org/
//
// LearnHub theme for IBS Software — Aviation & Travel LMS
// Moodle 4.5+ | Child theme of Boost

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'theme_learnhub';   // Must match folder name: theme/learnhub
$plugin->version   = 2025042201;          // YYYYMMDDXX
$plugin->requires  = 2024042200;          // Moodle 4.5+ (2024042200)
$plugin->release   = '1.0.1';
$plugin->maturity  = MATURITY_STABLE;
