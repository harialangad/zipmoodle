<?php
// This file is part of Moodle - http://moodle.org/
//
// LearnHub — lang/en/theme_learnhub.php
// All English strings for the theme. Moodle requires this file.

defined('MOODLE_INTERNAL') || die();

// ── Plugin identity ───────────────────────────────────────────────────────────
$string['pluginname']  = 'LearnHub';
$string['choosereadme'] = 'LearnHub is a professional Moodle theme for IBS Software, purpose-built for aviation and travel industry learning platforms. It features a branded hero dashboard, animated progress indicators, compliance certificate tracking, and an integrated AI Learning Assistant drawer.';
$string['configtitle'] = 'LearnHub settings';

// ── Settings tab labels ───────────────────────────────────────────────────────
$string['tab_branding']  = 'Branding';
$string['tab_hero']      = 'Hero & Dashboard';
$string['tab_ai']        = 'AI Assistant';
$string['tab_advanced']  = 'Advanced';

// ── Branding ──────────────────────────────────────────────────────────────────
$string['brandheading']      = 'Brand Identity';
$string['brandheading_desc'] = 'Configure the visual identity of your LearnHub platform.';
$string['logo']              = 'Logo';
$string['logo_desc']         = 'Upload your organisation logo (PNG/SVG, recommended height 40px). Displayed in the navigation bar.';
$string['favicon']           = 'Favicon';
$string['favicon_desc']      = 'Upload a favicon (.ico or PNG, 32×32px). Shown in browser tabs.';
$string['primarycolor']      = 'Primary colour';
$string['primarycolor_desc'] = 'Main brand colour used for navigation, buttons, and links. Default: #0f4c81 (IBS Navy).';
$string['accentcolor']       = 'Accent colour';
$string['accentcolor_desc']  = 'Highlight colour for CTAs, progress indicators, and badges. Default: #ff6b35 (IBS Orange).';
$string['brandname']         = 'Brand name';
$string['brandname_desc']    = 'Short name shown in the navigation bar (e.g., "LearnHub" or "IBS Academy").';

// ── Hero ──────────────────────────────────────────────────────────────────────
$string['enablehero']          = 'Enable hero banner';
$string['enablehero_desc']     = 'Show the full-width hero banner on the learner dashboard with progress ring and key stats.';
$string['herosubtitle']        = 'Hero subtitle / tagline';
$string['herosubtitle_desc']   = 'Short tagline displayed below the platform name in the hero banner.';
$string['industryvertical']    = 'Industry vertical';
$string['industryvertical_desc'] = 'Shown as a badge in the hero banner and used to contextualise the AI assistant.';
$string['vertical_aviation']   = 'Aviation';
$string['vertical_cruise']     = 'Cruise';
$string['vertical_travel']     = 'Travel';
$string['vertical_hospitality'] = 'Hospitality';
$string['heroimage']           = 'Hero background image';
$string['heroimage_desc']      = 'Optional background image for the hero banner (1920×600px recommended). Displays at low opacity over the gradient.';

// ── AI Assistant ──────────────────────────────────────────────────────────────
$string['enableaidrawer']         = 'Enable AI Learning Assistant';
$string['enableaidrawer_desc']    = 'Show the AI Assistant floating button (✦) on every page. Requires the Moodle AI Subsystem to be configured with at least one provider.';
$string['aigreeting']             = 'AI greeting message';
$string['aigreeting_desc']        = 'Opening message from the AI assistant. Use {firstname} as a placeholder for the user\'s first name.';
$string['aisystemprompt']         = 'AI system context';
$string['aisystemprompt_desc']    = 'System-level context sent to the AI provider with every request. Describe the platform, industry, and desired tone.';

// ── Advanced ──────────────────────────────────────────────────────────────────
$string['loginbg']              = 'Login page background';
$string['loginbg_desc']         = 'Background image for the login page (1920×1080px recommended).';
$string['footercontent']        = 'Footer content';
$string['footercontent_desc']   = 'HTML content for the site footer.';
$string['customcss']            = 'Custom CSS';
$string['customcss_desc']       = 'Raw CSS appended after all compiled styles. Use for one-off overrides.';

// ── UI Strings (used in templates and AMD) ────────────────────────────────────
$string['ibslearnhub']          = 'IBS Software · LearnHub';
$string['welcomeback']          = 'Welcome back, {$a}';
$string['aiassistant']          = 'AI Learning Assistant';
$string['aiready']              = 'Ready to help';
$string['aithinking']           = 'Thinking…';
$string['aierror']              = 'I\'m having trouble right now. Please try again.';
$string['aigreeting_default']   = 'Hi {$a}! I\'m your LearnHub AI assistant. Ask me anything about your courses or compliance requirements.';
$string['askaiassistant']       = 'Ask the AI assistant';
$string['aiinputplaceholder']   = 'Ask about your courses, compliance, or certifications…';
$string['openaiassistant']      = 'Open AI Learning Assistant';
$string['closeaiassistant']     = 'Close AI Learning Assistant';
$string['send']                 = 'Send';
$string['overallcompletion']    = 'Overall completion';
$string['overallprogress']      = 'Overall progress: {$a}%';
$string['mylearningpaths']      = 'My Learning Paths';
$string['upcomingactivities']   = 'Upcoming Activities';
$string['compliancecerts']      = 'Compliance Certifications';
$string['cohortstanding']       = 'Cohort Standing';
$string['announcements']        = 'Announcements';
$string['viewall']              = 'View all';
$string['viewallcourses']       = 'View all courses';
$string['continuecourse_short'] = 'Continue Learning';
$string['explorelearning']      = 'Explore Library';
$string['noenrolledcourses']    = 'You are not enrolled in any courses yet. Visit the course catalogue to get started.';
$string['noupcomingdeadlines']  = 'No upcoming deadlines — you\'re all caught up!';
$string['noannouncements']      = 'No recent announcements.';
$string['nocertificates']       = 'No certificates on record yet.';
$string['expires']              = 'Expires';
$string['outof']                = 'out of {$a}';
$string['done']                 = 'Done';
$string['remaining']            = 'Remaining';
$string['hrs']                  = 'hrs';
$string['yourprogress']         = 'Your progress';
$string['continuenext']         = 'Continue: {$a}';
$string['aisummary']            = 'AI Summary';
$string['contents']             = 'Contents';
$string['aigencoursesummary']   = 'Generate AI course summary';
$string['tableofcontents']      = 'Table of contents';
$string['coursetags']           = 'Course tags';
$string['required']             = 'Required';
$string['progresspercent']      = '{$a}% complete';
$string['learningmetrics']      = 'Learning metrics';
$string['quickstats']           = 'Quick stats';
$string['welcomebanner']        = 'Welcome banner';
$string['enrolledcourses']      = 'Enrolled courses';
$string['upcominglist']         = 'Upcoming activity list';
$string['conversation']         = 'AI conversation';
