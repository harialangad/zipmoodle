<?php
// This file is part of Moodle - http://moodle.org/
//
// LearnHub — db/upgrade.php

defined('MOODLE_INTERNAL') || die();

function xmldb_theme_learnhub_upgrade($oldversion): bool {
    global $DB, $CFG;
    $dbman = $DB->get_manager();

    // v1.0.1 — initial install handled by install.xml
    // Add future upgrade steps here using standard XMLDB patterns.

    return true;
}
