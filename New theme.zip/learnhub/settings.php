<?php
// This file is part of Moodle - http://moodle.org/
//
// LearnHub — settings.php
// Accessed via: Site admin → Appearance → Themes → LearnHub → Settings

defined('MOODLE_INTERNAL') || die();

if ($ADMIN->fulltree) {

    // Use Boost's tabbed settings page component for a clean admin UI
    $settings = new theme_boost_admin_settingspage_tabs(
        'theme_learnhub',
        get_string('configtitle', 'theme_learnhub')
    );

    // ── TAB 1: BRANDING ───────────────────────────────────────────────────────
    $page = new admin_settingpage(
        'theme_learnhub_branding',
        get_string('tab_branding', 'theme_learnhub')
    );

    $page->add(new admin_setting_heading(
        'theme_learnhub/brandheading',
        get_string('brandheading', 'theme_learnhub'),
        get_string('brandheading_desc', 'theme_learnhub')
    ));

    // Logo
    $page->add(new admin_setting_configstoredfile(
        'theme_learnhub/logo',
        get_string('logo', 'theme_learnhub'),
        get_string('logo_desc', 'theme_learnhub'),
        'logo', 0,
        ['maxfiles' => 1, 'accepted_types' => ['web_image']]
    ));

    // Favicon
    $page->add(new admin_setting_configstoredfile(
        'theme_learnhub/favicon',
        get_string('favicon', 'theme_learnhub'),
        get_string('favicon_desc', 'theme_learnhub'),
        'favicon', 0,
        ['maxfiles' => 1, 'accepted_types' => ['.ico', 'web_image']]
    ));

    // Primary colour
    $page->add(new admin_setting_configcolourpicker(
        'theme_learnhub/primarycolor',
        get_string('primarycolor', 'theme_learnhub'),
        get_string('primarycolor_desc', 'theme_learnhub'),
        '#0f4c81'
    ));

    // Accent colour
    $page->add(new admin_setting_configcolourpicker(
        'theme_learnhub/accentcolor',
        get_string('accentcolor', 'theme_learnhub'),
        get_string('accentcolor_desc', 'theme_learnhub'),
        '#ff6b35'
    ));

    // Brand / site name override shown in nav
    $page->add(new admin_setting_configtext(
        'theme_learnhub/brandname',
        get_string('brandname', 'theme_learnhub'),
        get_string('brandname_desc', 'theme_learnhub'),
        'LearnHub',
        PARAM_TEXT
    ));

    $settings->add($page);

    // ── TAB 2: HERO & DASHBOARD ───────────────────────────────────────────────
    $page = new admin_settingpage(
        'theme_learnhub_hero',
        get_string('tab_hero', 'theme_learnhub')
    );

    // Enable hero banner
    $page->add(new admin_setting_configcheckbox(
        'theme_learnhub/enablehero',
        get_string('enablehero', 'theme_learnhub'),
        get_string('enablehero_desc', 'theme_learnhub'),
        1
    ));

    // Hero subtitle / tagline
    $page->add(new admin_setting_configtext(
        'theme_learnhub/herosubtitle',
        get_string('herosubtitle', 'theme_learnhub'),
        get_string('herosubtitle_desc', 'theme_learnhub'),
        'IBS Software — Aviation & Travel Learning Platform',
        PARAM_TEXT
    ));

    // Industry vertical badge
    $page->add(new admin_setting_configselect(
        'theme_learnhub/industryvertical',
        get_string('industryvertical', 'theme_learnhub'),
        get_string('industryvertical_desc', 'theme_learnhub'),
        'Aviation',
        [
            'Aviation'      => get_string('vertical_aviation', 'theme_learnhub'),
            'Cruise'        => get_string('vertical_cruise', 'theme_learnhub'),
            'Travel'        => get_string('vertical_travel', 'theme_learnhub'),
            'Hospitality'   => get_string('vertical_hospitality', 'theme_learnhub'),
        ]
    ));

    // Hero background image
    $page->add(new admin_setting_configstoredfile(
        'theme_learnhub/heroimage',
        get_string('heroimage', 'theme_learnhub'),
        get_string('heroimage_desc', 'theme_learnhub'),
        'heroimage', 0,
        ['maxfiles' => 1, 'accepted_types' => ['web_image']]
    ));

    $settings->add($page);

    // ── TAB 3: AI ASSISTANT ───────────────────────────────────────────────────
    $page = new admin_settingpage(
        'theme_learnhub_ai',
        get_string('tab_ai', 'theme_learnhub')
    );

    // Enable AI drawer FAB
    $page->add(new admin_setting_configcheckbox(
        'theme_learnhub/enableaidrawer',
        get_string('enableaidrawer', 'theme_learnhub'),
        get_string('enableaidrawer_desc', 'theme_learnhub'),
        1
    ));

    // AI greeting message
    $page->add(new admin_setting_configtextarea(
        'theme_learnhub/aigreeting',
        get_string('aigreeting', 'theme_learnhub'),
        get_string('aigreeting_desc', 'theme_learnhub'),
        "Hi {firstname}! 👋 I'm your LearnHub AI assistant. I can help with course content, compliance questions, quiz preparation, or finding your next learning activity.",
        PARAM_TEXT
    ));

    // AI system prompt context
    $page->add(new admin_setting_configtextarea(
        'theme_learnhub/aisystemprompt',
        get_string('aisystemprompt', 'theme_learnhub'),
        get_string('aisystemprompt_desc', 'theme_learnhub'),
        'You are an AI learning assistant for aviation and travel industry professionals. Be concise, precise, and helpful.',
        PARAM_TEXT
    ));

    $settings->add($page);

    // ── TAB 4: ADVANCED ───────────────────────────────────────────────────────
    $page = new admin_settingpage(
        'theme_learnhub_advanced',
        get_string('tab_advanced', 'theme_learnhub')
    );

    // Login page background
    $page->add(new admin_setting_configstoredfile(
        'theme_learnhub/loginbg',
        get_string('loginbg', 'theme_learnhub'),
        get_string('loginbg_desc', 'theme_learnhub'),
        'loginbg', 0,
        ['maxfiles' => 1, 'accepted_types' => ['web_image']]
    ));

    // Footer text
    $page->add(new admin_setting_confightmleditor(
        'theme_learnhub/footercontent',
        get_string('footercontent', 'theme_learnhub'),
        get_string('footercontent_desc', 'theme_learnhub'),
        '<p>&copy; ' . date('Y') . ' IBS Software. All rights reserved.</p>',
        PARAM_RAW
    ));

    // Raw custom CSS
    $page->add(new admin_setting_configtextarea(
        'theme_learnhub/customcss',
        get_string('customcss', 'theme_learnhub'),
        get_string('customcss_desc', 'theme_learnhub'),
        '',
        PARAM_RAW
    ));

    $settings->add($page);
}
