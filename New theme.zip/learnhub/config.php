<?php
// This file is part of Moodle - http://moodle.org/
//
// LearnHub — config.php
// Registers the theme with Moodle's Theme Selector.
// Navigate: Site admin → Appearance → Themes → Theme selector → LearnHub

defined('MOODLE_INTERNAL') || die();

// ── Identity ──────────────────────────────────────────────────────────────────
$THEME->name        = 'learnhub';           // Must match directory name
$THEME->parents     = ['boost'];            // Inherit Boost (Bootstrap 4 + Moodle 4.x)
$THEME->usefallback = true;
$THEME->enable_dock = false;

// ── SCSS Pipeline ─────────────────────────────────────────────────────────────
// Moodle compiles these automatically on theme activation or cache purge.
// pre.scss  → injected BEFORE Boost/Bootstrap variables (for overrides)
// post.scss → injected AFTER  full Boost compilation (for new rules)

$THEME->scss = function ($theme) {
    return theme_learnhub_get_main_scss_content($theme);
};
$THEME->prescsscallback   = 'theme_learnhub_get_pre_scss';
$THEME->extrascsscallback = 'theme_learnhub_get_extra_scss';

// ── Page Layouts ──────────────────────────────────────────────────────────────
// Map every Moodle page type to a layout file in /layout/
$THEME->layouts = [
    // Learner dashboard (My Home)
    'mydashboard' => [
        'file'    => 'drawers.php',
        'regions' => ['side-pre'],
        'options' => ['nonavbar' => false, 'langmenu' => true],
    ],
    // Site front page
    'frontpage' => [
        'file'    => 'drawers.php',
        'regions' => ['side-pre'],
        'options' => ['nonavbar' => false, 'langmenu' => true],
    ],
    // Course main page
    'course' => [
        'file'    => 'drawers.php',
        'regions' => ['side-pre'],
        'options' => ['nonavbar' => false],
    ],
    // Inside a course activity
    'incourse' => [
        'file'    => 'drawers.php',
        'regions' => ['side-pre'],
        'options' => ['nonavbar' => false],
    ],
    // Admin / standard pages
    'admin' => [
        'file'    => 'drawers.php',
        'regions' => ['side-pre'],
        'options' => ['nonavbar' => false],
    ],
    'standard' => [
        'file'    => 'drawers.php',
        'regions' => ['side-pre'],
    ],
    'base' => [
        'file'    => 'drawers.php',
        'regions' => [],
    ],
    // Dedicated login page
    'login' => [
        'file'    => 'login.php',
        'regions' => [],
        'options' => ['nonavbar' => true, 'langmenu' => true, 'nofooter' => false],
    ],
    // Pop-up / modal windows
    'popup' => [
        'file'    => 'columns1.php',
        'regions' => [],
        'options' => ['nofooter' => true, 'nonavbar' => true],
    ],
    // Embedded (iframes)
    'embedded' => [
        'file'    => 'embedded.php',
        'regions' => [],
        'options' => ['nofooter' => true, 'nonavbar' => true],
    ],
    // Course in a box (used by some activities)
    'coursecategory' => [
        'file'    => 'drawers.php',
        'regions' => ['side-pre'],
    ],
    // Reports / printing
    'print' => [
        'file'    => 'columns1.php',
        'regions' => [],
        'options' => ['nofooter' => true, 'nonavbar' => false, 'noblocks' => true],
    ],
    'maintenance' => [
        'file'    => 'maintenance.php',
        'regions' => [],
        'options' => ['nofooter' => true, 'nonavbar' => true, 'noblocks' => true],
    ],
    'secure' => [
        'file'    => 'secure.php',
        'regions' => ['side-pre'],
        'options' => ['nofooter' => true, 'nonavbar' => false],
    ],
];

// ── Block regions Boost exposes ────────────────────────────────────────────────
$THEME->blockrendermethod = 'blocks';

// ── Sheet & editor ────────────────────────────────────────────────────────────
$THEME->sheets        = [];   // Raw CSS sheets — not used; we use SCSS pipeline
$THEME->editor_sheets = [];

// ── Remove unwanted primary nav items ─────────────────────────────────────────
$THEME->removedprimarynavitems = [];
