<?php
// This file is part of Moodle - http://moodle.org/
//
// LearnHub — classes/output/core_renderer.php
// Extends Boost's core renderer to inject LearnHub-specific data
// into the drawers template context (hero stats, AI greeting, etc.)

namespace theme_learnhub\output;

defined('MOODLE_INTERNAL') || die();

use context_user;
use moodle_url;
use stdClass;

require_once($CFG->dirroot . '/theme/boost/classes/output/core_renderer.php');

/**
 * LearnHub core renderer — extends theme_boost\output\core_renderer.
 */
class core_renderer extends \theme_boost\output\core_renderer {

    /**
     * Override full_header() to inject the LearnHub hero data attributes
     * on the page header element so the AMD module can read them.
     *
     * @return string
     */
    public function full_header(): string {
        global $USER, $PAGE;

        $html = parent::full_header();

        // Inject data-progress on dashboard only (AMD reads it for the ring)
        if ($PAGE->pagelayout === 'mydashboard' && isloggedin() && !isguestuser()) {
            $progress = $this->get_overall_progress($USER->id);
            $html     = str_replace(
                'id="page-header"',
                'id="page-header" data-lh-progress="' . (int)$progress . '"',
                $html
            );
        }

        return $html;
    }

    /**
     * Calculate approximate overall course progress (%) for the ring.
     * Falls back gracefully if the completion subsystem is unavailable.
     *
     * @param int $userid
     * @return float  0–100
     */
    protected function get_overall_progress(int $userid): float {
        $courses = enrol_get_users_courses($userid, true, ['enablecompletion'], 'id ASC');
        if (empty($courses)) {
            return 0.0;
        }

        $totalactivities = 0;
        $doneactivities  = 0;

        foreach ($courses as $course) {
            if (empty($course->enablecompletion)) {
                continue;
            }

            try {
                $completion = new \completion_info($course);
                if (!$completion->is_enabled()) {
                    continue;
                }

                $activities = $completion->get_activities();
                $totalactivities += count($activities);

                foreach ($activities as $cm) {
                    $data = $completion->get_data($cm, false, $userid);
                    if (in_array($data->completionstate,
                        [COMPLETION_COMPLETE, COMPLETION_COMPLETE_PASS], true)) {
                        $doneactivities++;
                    }
                }
            } catch (\Throwable $e) {
                // Silently skip if completion is misconfigured for this course
                continue;
            }
        }

        if ($totalactivities === 0) {
            return 0.0;
        }

        return round(($doneactivities / $totalactivities) * 100, 1);
    }

    /**
     * Build the personalised AI greeting string for the drawer template.
     * Replaces {firstname} placeholder with the actual user's first name.
     *
     * @return string
     */
    public function get_ai_greeting(): string {
        global $USER;

        $template = get_config('theme_learnhub', 'aigreeting')
            ?: get_string('aigreeting_default', 'theme_learnhub', $USER->firstname);

        return str_replace('{firstname}', $USER->firstname, $template);
    }

    /**
     * Render the AI FAB + Drawer via the drawers template context.
     * Called from layout/drawers.php via $OUTPUT.
     *
     * @return string HTML
     */
    public function render_ai_drawer(): string {
        global $USER;

        if (!isloggedin() || isguestuser()) {
            return '';
        }

        if (!get_config('theme_learnhub', 'enableaidrawer')) {
            return '';
        }

        $context = [
            'enableaidrawer' => true,
            'isloggedin'     => true,
            'userfirstname'  => $USER->firstname,
            'aigreeting'     => $this->get_ai_greeting(),
            'aiplacementid'  => 'learnhub_dashboard',
            'aiserviceurl'   => (new moodle_url('/theme/learnhub/ajax/ai_chat.php'))->out(false),
            'sesskey'        => sesskey(),
        ];

        return $this->render_from_template('theme_learnhub/ai_drawer', $context);
    }
}
