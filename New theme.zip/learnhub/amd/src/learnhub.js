// =============================================================================
// LearnHub — amd/src/learnhub.js
// Main AMD module loaded on every page via theme_learnhub_page_init().
// Handles: AI Drawer, SVG progress ring, counter animations, nav enhancements.
//
// Moodle AMD requires a define() wrapper and explicit dependency list.
// Build with:  grunt amd   (or npx grunt amd  in theme root)
// =============================================================================

/**
 * @module theme_learnhub/learnhub
 */
define([
    'jquery',
    'core/ajax',
    'core/notification',
    'core/str',
], function($, Ajax, Notification, Str) {

    'use strict';

    // ── Constants ────────────────────────────────────────────────────────────
    const SEL = {
        FAB:        '#lh-ai-fab',
        DRAWER:     '#lh-ai-drawer',
        CLOSE:      '#lh-ai-close',
        BACKDROP:   '#lh-ai-backdrop',
        MESSAGES:   '#lh-ai-messages',
        INPUT:      '#lh-ai-input',
        SEND:       '#lh-ai-send',
        STATUS:     '#lh-ai-status',
        RING:       '.lh-progress-ring-circle',
        RING_TXT:   '.lh-ring-pct-text',
        COUNTERS:   '[data-lh-count]',
    };

    let _cfg = {};
    let _open = false;
    let _history = [];

    // =========================================================================
    // PUBLIC API
    // =========================================================================
    return {
        /**
         * Entry point called by theme_learnhub_page_init() in lib.php.
         * @param {Object} config  – {userid, sesskey, enableAiDrawer, aiServiceUrl, layout}
         */
        init: function(config) {
            _cfg = config || {};
            _enhanceNavbar();
            _animateProgressRing();
            _animateCounters();
            if (_cfg.enableAiDrawer) {
                _initAiDrawer();
                _buildAiGreeting();
            }
        },
    };

    // =========================================================================
    // NAV ENHANCEMENT
    // =========================================================================
    function _enhanceNavbar() {
        // Mark active nav link from URL
        const path = window.location.pathname;
        document.querySelectorAll('.nav-link').forEach(function(link) {
            if (link.getAttribute('href') && path.startsWith(link.getAttribute('href'))) {
                link.classList.add('active');
                link.setAttribute('aria-current', 'page');
            }
        });
    }

    // =========================================================================
    // PROGRESS RING  (dashboard hero SVG circle)
    // =========================================================================
    function _animateProgressRing() {
        const ring = document.querySelector(SEL.RING);
        const txt  = document.querySelector(SEL.RING_TXT);
        if (!ring) return;

        // Fetch the user's overall completion from Moodle web service
        Ajax.call([{
            methodname: 'core_completion_get_course_completion_condition_data',
            args: { courseid: 0 },  // 0 = aggregate across all courses
        }])[0].then(function(data) {
            const pct = data.overall || 0;
            _setRing(ring, txt, pct);
        }).catch(function() {
            // Fallback: try to read from page data attribute or default to 0
            const hero = document.getElementById('lh-hero-banner');
            const pct  = hero ? parseInt(hero.dataset.progress || 0, 10) : 0;
            _setRing(ring, txt, pct);
        });
    }

    function _setRing(ring, txt, pct) {
        const circumference = 427.3; // 2 * PI * 68
        const offset = circumference - (pct / 100) * circumference;

        // Delay for entrance animation
        setTimeout(function() {
            ring.style.transition = 'stroke-dashoffset 1.4s cubic-bezier(0.16,1,0.3,1)';
            ring.style.strokeDashoffset = offset;
            if (txt) txt.textContent = pct + '%';
        }, 400);
    }

    // =========================================================================
    // COUNTER ANIMATIONS  (stat tiles with data-lh-count attribute)
    // =========================================================================
    function _animateCounters() {
        const elements = document.querySelectorAll(SEL.COUNTERS);
        if (!elements.length) return;

        const observer = new IntersectionObserver(function(entries) {
            entries.forEach(function(entry) {
                if (!entry.isIntersecting) return;
                const el     = entry.target;
                const target = parseFloat(el.dataset.lhCount);
                const suffix = el.dataset.lhSuffix || '';
                if (isNaN(target)) return;

                let start = null;
                const duration = 1200;

                function step(ts) {
                    if (!start) start = ts;
                    const progress = Math.min((ts - start) / duration, 1);
                    const eased    = 1 - Math.pow(1 - progress, 4);
                    el.textContent = Math.round(eased * target) + suffix;
                    if (progress < 1) requestAnimationFrame(step);
                }

                requestAnimationFrame(step);
                observer.unobserve(el);
            });
        }, { threshold: 0.5 });

        elements.forEach(function(el) { observer.observe(el); });
    }

    // =========================================================================
    // AI DRAWER
    // =========================================================================
    function _initAiDrawer() {
        const fab      = document.querySelector(SEL.FAB);
        const closeBtn = document.querySelector(SEL.CLOSE);
        const backdrop = document.querySelector(SEL.BACKDROP);
        const input    = document.querySelector(SEL.INPUT);
        const send     = document.querySelector(SEL.SEND);

        if (!fab) return;

        fab.addEventListener('click', _toggleDrawer);
        closeBtn && closeBtn.addEventListener('click', _closeDrawer);
        backdrop && backdrop.addEventListener('click', _closeDrawer);

        // Keyboard
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && _open) _closeDrawer();
            // Ctrl/Cmd + Shift + A
            if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'A') {
                e.preventDefault();
                _toggleDrawer();
            }
        });

        // Auto-resize textarea
        if (input) {
            input.addEventListener('input', function() {
                input.style.height = 'auto';
                input.style.height = Math.min(input.scrollHeight, 120) + 'px';
                send && (send.disabled = !input.value.trim());
            });
            input.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    if (input.value.trim()) _sendMessage();
                }
            });
        }

        send && send.addEventListener('click', _sendMessage);
    }

    function _buildAiGreeting() {
        // Replace {firstname} placeholder in the drawer greeting bubble
        const msgBox   = document.querySelector(SEL.MESSAGES);
        const greeting = document.querySelector('.lh-ai-drawer__bubble--ai');
        if (!greeting || !msgBox) return;

        const firstname = _cfg.userfirstname || '';
        greeting.textContent = greeting.textContent.replace('{firstname}', firstname);
    }

    function _toggleDrawer() { _open ? _closeDrawer() : _openDrawer(); }

    function _openDrawer() {
        const fab      = document.querySelector(SEL.FAB);
        const drawer   = document.querySelector(SEL.DRAWER);
        const backdrop = document.querySelector(SEL.BACKDROP);
        if (!drawer) return;

        drawer.classList.add('is-open');
        drawer.setAttribute('aria-hidden', 'false');
        backdrop && backdrop.classList.add('is-visible');
        fab && fab.setAttribute('aria-expanded', 'true');
        _open = true;

        setTimeout(function() {
            const input = document.querySelector(SEL.INPUT);
            input && input.focus();
        }, 350);
    }

    function _closeDrawer() {
        const fab      = document.querySelector(SEL.FAB);
        const drawer   = document.querySelector(SEL.DRAWER);
        const backdrop = document.querySelector(SEL.BACKDROP);
        if (!drawer) return;

        drawer.classList.remove('is-open');
        drawer.setAttribute('aria-hidden', 'true');
        backdrop && backdrop.classList.remove('is-visible');
        fab && fab.setAttribute('aria-expanded', 'false');
        _open = false;
        fab && fab.focus();
    }

    function _sendMessage() {
        const input  = document.querySelector(SEL.INPUT);
        const status = document.querySelector(SEL.STATUS);
        const text   = input ? input.value.trim() : '';
        if (!text) return;

        // Clear input
        if (input) {
            input.value = '';
            input.style.height = 'auto';
            const send = document.querySelector(SEL.SEND);
            send && (send.disabled = true);
        }

        // Append user bubble
        _appendBubble(text, 'user');
        _history.push({ role: 'user', content: text });

        // Typing indicator
        const typingId = _appendTyping();

        // Update status
        Str.get_string('aithinking', 'theme_learnhub').then(function(s) {
            if (status) status.textContent = s;
        });

        // POST to AJAX endpoint (theme/learnhub/ajax/ai_chat.php)
        $.ajax({
            url:    _cfg.aiServiceUrl,
            method: 'POST',
            data: {
                sesskey:  _cfg.sesskey,
                userid:   _cfg.userid,
                message:  text,
                history:  JSON.stringify(_history.slice(-8)),
            },
        }).done(function(resp) {
            _removeTyping(typingId);
            const reply = resp.message || resp.error || '…';
            _appendBubble(reply, 'ai');
            _history.push({ role: 'assistant', content: reply });
            Str.get_string('aiready', 'theme_learnhub').then(function(s) {
                if (status) status.textContent = s;
            });
        }).fail(function() {
            _removeTyping(typingId);
            Str.get_string('aierror', 'theme_learnhub').then(function(s) {
                _appendBubble(s, 'ai');
                if (status) status.textContent = '⚠ Error';
            });
        });
    }

    function _appendBubble(text, type) {
        const container = document.querySelector(SEL.MESSAGES);
        if (!container) return null;

        const div = document.createElement('div');
        div.className = 'lh-ai-drawer__bubble lh-ai-drawer__bubble--' + type;
        div.textContent = text;
        container.appendChild(div);
        container.scrollTop = container.scrollHeight;
        return div;
    }

    function _appendTyping() {
        const container = document.querySelector(SEL.MESSAGES);
        if (!container) return null;

        const id  = 'lh-typing-' + Date.now();
        const div = document.createElement('div');
        div.id        = id;
        div.className = 'lh-ai-drawer__typing';
        div.setAttribute('aria-label', 'AI is thinking');
        div.innerHTML = '<span></span><span></span><span></span>';
        container.appendChild(div);
        container.scrollTop = container.scrollHeight;
        return id;
    }

    function _removeTyping(id) {
        if (id) {
            const el = document.getElementById(id);
            el && el.remove();
        }
    }

});
