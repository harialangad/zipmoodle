<?php
// This file is part of Moodle - http://moodle.org/
//
// LearnHub — layout/drawers.php
// Main layout for dashboard, course, incourse, standard, admin pages.
// Based on Boost's drawers.php with LearnHub hero, AI FAB, and custom footer.

defined('MOODLE_INTERNAL') || die();

/** @var core_renderer $OUTPUT */
/** @var moodle_page   $PAGE */

$bodyattributes   = $OUTPUT->body_attributes();
$blockshtml       = $OUTPUT->blocks('side-pre');
$hasblocks        = strpos($blockshtml, 'data-block=') !== false;
$extraclasses     = [];
$buildregionmain  = '';
$hasfootercontent = get_config('theme_learnhub', 'footercontent');
$enablehero       = get_config('theme_learnhub', 'enablehero');
$enableaidrawer   = get_config('theme_learnhub', 'enableaidrawer');
$isdashboard      = $PAGE->pagelayout === 'mydashboard';
$brandname        = get_config('theme_learnhub', 'brandname') ?: 'LearnHub';
$industryvertical = get_config('theme_learnhub', 'industryvertical') ?: 'Aviation';

// Build template context
$templatecontext = theme_learnhub_get_template_context($OUTPUT, $PAGE);
$templatecontext += [
    'sitename'          => format_string($SITE->fullname),
    'output'            => $OUTPUT,
    'bodyattributes'    => $bodyattributes,
    'sidepreblocks'     => $blockshtml,
    'hasblocks'         => $hasblocks,
    'regionmaincontent' => $OUTPUT->main_content(),
    'addblockbutton'    => $OUTPUT->addblockbutton('side-pre'),
    'primarynavigation' => $OUTPUT->primary_nav(),
    'pageheadingbutton' => $OUTPUT->page_heading_button(),
    'courseindexdrawer' => $OUTPUT->activity_navigation(),
    'hasnavdrawer'      => true,
    'navdrawer'         => $OUTPUT->navigation_xdrawer(),
    'headercontent'     => $OUTPUT->full_header(),
    'footeralert'       => $OUTPUT->footer(),
    'brandname'         => $brandname,
    'industryvertical'  => $industryvertical,
    'isdashboard'       => $isdashboard,
    'enablehero'        => !empty($enablehero) && $isdashboard,
    'enableaidrawer'    => !empty($enableaidrawer),
    'footercontent'     => format_text($hasfootercontent ?: '<p>&copy; ' . date('Y') . ' IBS Software. All rights reserved.</p>', FORMAT_HTML),
];

// Page layout class additions
if ($isdashboard) {
    $extraclasses[] = 'lh-page-dashboard';
}
$templatecontext['extraclasses'] = implode(' ', $extraclasses);

echo $OUTPUT->render_from_template('theme_learnhub/drawers', $templatecontext);
