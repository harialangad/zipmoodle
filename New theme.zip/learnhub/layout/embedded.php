<?php
// LearnHub — layout/embedded.php
defined('MOODLE_INTERNAL') || die();
$templatecontext = ['output' => $OUTPUT, 'bodyattributes' => $OUTPUT->body_attributes(),
    'regionmaincontent' => $OUTPUT->main_content()];
echo $OUTPUT->render_from_template('theme_learnhub/embedded', $templatecontext);
