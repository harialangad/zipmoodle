<?php
// LearnHub — layout/secure.php (e.g. quiz in progress)
defined('MOODLE_INTERNAL') || die();
$templatecontext = ['output' => $OUTPUT, 'bodyattributes' => $OUTPUT->body_attributes(),
    'sitename' => format_string($SITE->fullname), 'regionmaincontent' => $OUTPUT->main_content(),
    'sidepreblocks' => $OUTPUT->blocks('side-pre')];
echo $OUTPUT->render_from_template('theme_learnhub/secure', $templatecontext);
