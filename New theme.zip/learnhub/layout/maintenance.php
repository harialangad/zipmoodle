<?php
// LearnHub — layout/maintenance.php
defined('MOODLE_INTERNAL') || die();
$templatecontext = ['output' => $OUTPUT, 'bodyattributes' => $OUTPUT->body_attributes(),
    'sitename' => format_string($SITE->fullname), 'regionmaincontent' => $OUTPUT->main_content()];
echo $OUTPUT->render_from_template('theme_learnhub/maintenance', $templatecontext);
