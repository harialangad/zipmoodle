<?php
// This file is part of Moodle - http://moodle.org/
//
// LearnHub — layout/login.php
// Custom two-column login page layout.

defined('MOODLE_INTERNAL') || die();

$templatecontext = [
    'output'        => $OUTPUT,
    'bodyattributes'=> $OUTPUT->body_attributes(),
    'sitename'      => format_string($SITE->fullname),
    'brandname'     => get_config('theme_learnhub', 'brandname') ?: 'LearnHub',
    'herosubtitle'  => get_config('theme_learnhub', 'herosubtitle') ?: 'Aviation & Travel Learning Platform',
    'logincontent'  => $OUTPUT->main_content(),
    'hasfooter'     => true,
    'footercontent' => format_text(
        get_config('theme_learnhub', 'footercontent') ?: '<p>&copy; ' . date('Y') . ' IBS Software. All rights reserved.</p>',
        FORMAT_HTML
    ),
    // Login page bg image URL
    'loginbgurl'    => theme_learnhub_get_setting_file_url('loginbg'),
];

echo $OUTPUT->render_from_template('theme_learnhub/login', $templatecontext);

// ---------------------------------------------------------------------------
// Helper — get URL for a stored-file setting
// ---------------------------------------------------------------------------
function theme_learnhub_get_setting_file_url(string $area): string {
    $theme = theme_config::load('learnhub');
    $files = $theme->setting_file_url($area, $area);
    return $files ?: '';
}
