<?php
// This file is part of Moodle - http://moodle.org/
//
// LearnHub — ajax/ai_chat.php
// AJAX endpoint for the AI Learning Assistant drawer.
// Receives the learner's message, enriches it with Moodle context,
// and proxies it through the Moodle AI Subsystem (core_ai).
//
// Request: POST  — {sesskey, userid, message, history (JSON)}
// Response: JSON — {message: string} or {error: string}

define('AJAX_SCRIPT', true);
require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/filelib.php');

// ── Security ─────────────────────────────────────────────────────────────────
require_login();
require_sesskey();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    die(json_encode(['error' => 'Method not allowed']));
}

$userid  = required_param('userid',  PARAM_INT);
$message = required_param('message', PARAM_TEXT);
$history = optional_param('history', '[]', PARAM_RAW);

// Verify the requesting user matches the session user
if ($userid !== (int)$USER->id) {
    http_response_code(403);
    die(json_encode(['error' => 'Forbidden']));
}

// Sanitise message
$message = clean_param($message, PARAM_TEXT);
if (strlen($message) > 2000 || strlen(trim($message)) === 0) {
    http_response_code(400);
    die(json_encode(['error' => 'Invalid message']));
}

// Decode conversation history (last 8 turns for context window)
$historyarray = [];
try {
    $decoded = json_decode($history, true, 8, JSON_THROW_ON_ERROR);
    if (is_array($decoded)) {
        $historyarray = array_slice($decoded, -8);
    }
} catch (Throwable $e) {
    $historyarray = [];
}

// ── Build AI context ─────────────────────────────────────────────────────────
$context         = context_system::instance();
$systemprompt    = get_config('theme_learnhub', 'aisystemprompt')
    ?: 'You are an AI learning assistant for aviation and travel industry professionals on the LearnHub platform by IBS Software. Be concise, precise, and professional. Keep responses under 180 words.';

// Enrich with learner-specific context
$usercourses      = enrol_get_users_courses($USER->id, true, ['fullname', 'shortname'], 'fullname ASC');
$coursecontextstr = '';
foreach ($usercourses as $course) {
    $completion       = new completion_info($course);
    $coursecontextstr .= '- ' . $course->fullname . "\n";
}

$enrichedsystem = $systemprompt
    . "\n\nCurrent learner: " . fullname($USER)
    . " (ID: {$USER->id})"
    . "\nEnrolled courses:\n" . ($coursecontextstr ?: 'No active enrolments.')
    . "\nIndustry vertical: " . (get_config('theme_learnhub', 'industryvertical') ?: 'Aviation');

// ── Try Moodle AI Subsystem (4.5+) ───────────────────────────────────────────
$airesponse = null;

if (class_exists('\core_ai\manager')) {
    try {
        $aimanager = \core_ai\manager::get_instance();

        // Build message array including conversation history
        $messages = [];
        foreach ($historyarray as $turn) {
            if (!empty($turn['role']) && !empty($turn['content'])) {
                $messages[] = [
                    'role'    => $turn['role'] === 'assistant' ? 'assistant' : 'user',
                    'content' => clean_param($turn['content'], PARAM_TEXT),
                ];
            }
        }
        $messages[] = ['role' => 'user', 'content' => $message];

        $action = new \core_ai\action\generate_text(
            contextid:     $context->id,
            userid:        $USER->id,
            prompttext:    $message,
            conversationid: null,
            // Some providers accept a system prompt via extra options
            systemprompt:  $enrichedsystem,
        );

        $response = $aimanager->process_action($action);

        if ($response && $response->get_success()) {
            $airesponse = $response->get_generated_content();
        }
    } catch (Throwable $e) {
        debugging('LearnHub AI Subsystem error: ' . $e->getMessage(), DEBUG_DEVELOPER);
    }
}

// ── Fallback: direct HTTP call to OpenAI-compatible provider ─────────────────
// Used when Moodle AI Subsystem is not configured but an API key is set.
if ($airesponse === null) {
    $apikey = get_config('theme_learnhub', 'openai_api_key');
    if (!empty($apikey)) {
        $airesponse = theme_learnhub_call_openai($apikey, $enrichedsystem, $historyarray, $message);
    }
}

// ── Final fallback ────────────────────────────────────────────────────────────
if ($airesponse === null) {
    $airesponse = get_string('aierror', 'theme_learnhub');
}

// ── Rate limit logging ────────────────────────────────────────────────────────
theme_learnhub_log_ai_interaction($USER->id, strlen($message), strlen($airesponse));

// ── Response ──────────────────────────────────────────────────────────────────
header('Content-Type: application/json');
echo json_encode([
    'message'   => $airesponse,
    'userid'    => $USER->id,
    'timestamp' => time(),
]);
exit;


// =============================================================================
// HELPERS
// =============================================================================

/**
 * Direct OpenAI API call (fallback when Moodle AI Subsystem unavailable).
 */
function theme_learnhub_call_openai(
    string $apikey,
    string $system,
    array  $history,
    string $message
): ?string {
    $messages = [['role' => 'system', 'content' => $system]];
    foreach ($history as $turn) {
        if (!empty($turn['role']) && !empty($turn['content'])) {
            $messages[] = ['role' => $turn['role'], 'content' => $turn['content']];
        }
    }
    $messages[] = ['role' => 'user', 'content' => $message];

    $payload = json_encode([
        'model'       => 'gpt-4o-mini',
        'messages'    => $messages,
        'max_tokens'  => 300,
        'temperature' => 0.55,
    ]);

    $ch = curl_init('https://api.openai.com/v1/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => [
            'Authorization: Bearer ' . $apikey,
            'Content-Type: application/json',
        ],
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $raw  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code !== 200 || !$raw) {
        return null;
    }

    $data = json_decode($raw, true);
    return $data['choices'][0]['message']['content'] ?? null;
}

/**
 * Log AI interactions for audit trail.
 * Writes to {learnhub_ai_log} table created in db/install.xml.
 */
function theme_learnhub_log_ai_interaction(int $userid, int $promptlen, int $responselen): void {
    global $DB;
    try {
        $DB->insert_record('learnhub_ai_log', (object)[
            'userid'         => $userid,
            'prompt_chars'   => $promptlen,
            'response_chars' => $responselen,
            'timecreated'    => time(),
        ]);
    } catch (Throwable $e) {
        // Table may not exist yet — silently skip
        debugging('LearnHub AI log error: ' . $e->getMessage(), DEBUG_DEVELOPER);
    }
}
