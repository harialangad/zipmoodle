/**
 * LearnHub — Gruntfile.js
 * Compiles amd/src/ → amd/build/  (uglified + source-mapped)
 * Run:  npm install && grunt amd
 */
'use strict';

module.exports = function(grunt) {
    grunt.initConfig({
        uglify: {
            amd: {
                options: {
                    sourceMap: true,
                    sourceMapName: function(dest) { return dest + '.map'; },
                    compress: { drop_console: false },
                    mangle: true,
                },
                files: [{
                    expand:  true,
                    cwd:     'amd/src',
                    src:     '**/*.js',
                    dest:    'amd/build',
                    ext:     '.min.js',
                }],
            },
        },
        eslint: {
            options: { configFile: '.eslintrc' },
            amd:     { src: ['amd/src/**/*.js'] },
        },
        watch: {
            amd: {
                files: ['amd/src/**/*.js'],
                tasks: ['uglify:amd'],
            },
        },
    });

    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-eslint');
    grunt.loadNpmTasks('grunt-contrib-watch');

    grunt.registerTask('amd',     ['eslint:amd', 'uglify:amd']);
    grunt.registerTask('default', ['amd']);
};
