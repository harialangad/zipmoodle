<?php
// This file is part of Moodle - http://moodle.org/
//
// LearnHub — lib.php
// SCSS pipeline callbacks + page_init hook + pluginfile handler

defined('MOODLE_INTERNAL') || die();


// =============================================================================
// SCSS PIPELINE
// =============================================================================

/**
 * Injected BEFORE Boost/Bootstrap SCSS is compiled.
 * Use this to override Bootstrap $variables and Boost $variables.
 *
 * @param theme_config $theme
 * @return string
 */
function theme_learnhub_get_pre_scss($theme): string {
    $primary = $theme->settings->primarycolor ?? '#0f4c81';
    $accent  = $theme->settings->accentcolor  ?? '#ff6b35';

    // Override Bootstrap's $primary so every Boost component picks up our brand colour.
    return <<<SCSS
// ── LearnHub Brand Overrides (pre-Bootstrap) ──────────────────────────────
\$primary:           {$primary};
\$link-color:        {$primary};
\$btn-border-radius: 8px;
\$navbar-dark-color: rgba(255, 255, 255, 0.75);
\$font-size-base:    1rem;
\$headings-color:    #1b2230;
SCSS;
}

/**
 * Main SCSS content — Boost parent first, then our overrides.
 *
 * @param theme_config $theme
 * @return string
 */
function theme_learnhub_get_main_scss_content($theme): string {
    global $CFG;

    $scss = '';

    // 1. Boost parent preset (Bootstrap + Moodle components)
    $preset = $CFG->dirroot . '/theme/boost/scss/preset/default.scss';
    if (file_exists($preset)) {
        $scss .= file_get_contents($preset) . "\n\n";
    }

    // 2. LearnHub post-compilation styles
    $post = $CFG->dirroot . '/theme/learnhub/scss/post.scss';
    if (file_exists($post)) {
        $scss .= file_get_contents($post);
    }

    return $scss;
}

/**
 * Injected AFTER all SCSS is compiled — used for admin custom CSS and
 * runtime CSS variable injection.
 *
 * @param theme_config $theme
 * @return string
 */
function theme_learnhub_get_extra_scss($theme): string {
    $primary      = $theme->settings->primarycolor ?? '#0f4c81';
    $accent       = $theme->settings->accentcolor  ?? '#ff6b35';
    $primarydark  = theme_learnhub_darken_hex($primary, 0.3);
    $primarylight = theme_learnhub_lighten_hex($primary, 0.15);

    // Inject CSS custom properties so they can be used by AMD modules / templates.
    $extra = <<<CSS
:root {
    --lh-primary:       {$primary};
    --lh-primary-dark:  {$primarydark};
    --lh-primary-light: {$primarylight};
    --lh-accent:        {$accent};
    --lh-primary-glass: rgba(15, 76, 129, 0.08);
    --lh-n50:   #f7f8fa; --lh-n100: #eef0f4; --lh-n200: #dde1e9;
    --lh-n400:  #8e98ab; --lh-n500: #606c80; --lh-n600: #404c5e;
    --lh-n700:  #2c3645; --lh-n800: #1b2230;
    --lh-success: #0d9b6c; --lh-warning: #c98a00; --lh-danger: #c0392b;
    --lh-shadow-sm: 0 2px 6px rgba(14,21,32,.08), 0 1px 2px rgba(14,21,32,.04);
    --lh-shadow-md: 0 4px 16px rgba(14,21,32,.10), 0 2px 4px rgba(14,21,32,.06);
    --lh-shadow-lg: 0 8px 32px rgba(14,21,32,.12), 0 4px 8px rgba(14,21,32,.06);
    --lh-shadow-xl: 0 16px 48px rgba(14,21,32,.16), 0 6px 12px rgba(14,21,32,.08);
    --lh-font-display: 'Playfair Display', Georgia, serif;
    --lh-font-ui:      'DM Sans', 'Helvetica Neue', sans-serif;
    --lh-navbar-height: 64px;
    --lh-drawer-width:  360px;
}
CSS;

    // Admin custom CSS field
    if (!empty($theme->settings->customcss)) {
        $extra .= "\n/* === Admin custom CSS === */\n" . $theme->settings->customcss;
    }

    return $extra;
}


// =============================================================================
// PAGE INIT — Inject AMD modules per layout
// =============================================================================

/**
 * Called by Moodle for every page render.
 * Use this to require AMD modules and pass server-side config to JS.
 *
 * @param moodle_page $page
 */
function theme_learnhub_page_init(moodle_page $page): void {
    global $USER, $CFG;

    // Google Fonts — loaded via JS to avoid render-blocking
    $page->requires->js_amd_inline("
        (function(){
            var l = document.createElement('link');
            l.rel = 'stylesheet';
            l.href = 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Source+Sans+3:wght@300;400;500;600;700&family=DM+Sans:wght@400;500;600&display=swap';
            document.head.appendChild(l);
        })();
    ");

    if (!isloggedin() || isguestuser()) {
        return;
    }

    $config = [
        'userid'          => (int)$USER->id,
        'sesskey'         => sesskey(),
        'enableAiDrawer'  => !empty(get_config('theme_learnhub', 'enableaidrawer')),
        'enableHero'      => !empty(get_config('theme_learnhub', 'enablehero')),
        'primarycolor'    => get_config('theme_learnhub', 'primarycolor') ?: '#0f4c81',
        'accentcolor'     => get_config('theme_learnhub', 'accentcolor')  ?: '#ff6b35',
        'aiPlacementId'   => 'learnhub_dashboard',
        'aiServiceUrl'    => (new moodle_url('/theme/learnhub/ajax/ai_chat.php'))->out(false),
        'layout'          => $page->pagelayout,
    ];

    $page->requires->js_call_amd('theme_learnhub/learnhub', 'init', [$config]);
}


// =============================================================================
// RENDERER OVERRIDE — Pass extra context to Boost's output renderer
// =============================================================================

/**
 * Returns additional template context vars available in all learnhub templates.
 *
 * @param renderer_base $output
 * @param moodle_page   $page
 * @return array
 */
function theme_learnhub_get_template_context(renderer_base $output, moodle_page $page): array {
    global $USER, $SITE;

    return [
        'sitename'          => format_string($SITE->fullname),
        'siteshortname'     => format_string($SITE->shortname),
        'userid'            => (int)$USER->id,
        'userfullname'      => isloggedin() ? fullname($USER) : '',
        'userfirstname'     => isloggedin() ? $USER->firstname : '',
        'sesskey'           => sesskey(),
        'dashboardurl'      => (new moodle_url('/my'))->out(false),
        'allcoursesurl'     => (new moodle_url('/course/index.php'))->out(false),
        'profileurl'        => (new moodle_url('/user/profile.php', ['id' => $USER->id]))->out(false),
        'aiplacementid'     => 'learnhub_dashboard',
        'aiserviceurl'      => (new moodle_url('/theme/learnhub/ajax/ai_chat.php'))->out(false),
        'enableaidrawer'    => !empty(get_config('theme_learnhub', 'enableaidrawer')),
        'herosubtitle'      => get_config('theme_learnhub', 'herosubtitle') ?: 'IBS Software — Aviation & Travel Learning Platform',
        'industryvertical'  => get_config('theme_learnhub', 'industryvertical') ?: 'Aviation',
        'isloggedin'        => isloggedin() && !isguestuser(),
        'pagelayout'        => $page->pagelayout,
        'isdashboard'       => $page->pagelayout === 'mydashboard',
    ];
}


// =============================================================================
// PLUGINFILE — serve theme-managed files (logo, hero image, favicon)
// =============================================================================

/**
 * @param stdClass  $course
 * @param stdClass  $cm
 * @param context   $context
 * @param string    $filearea
 * @param array     $args
 * @param bool      $forcedownload
 * @param array     $options
 * @return bool|void
 */
function theme_learnhub_pluginfile(
    $course, $cm, context $context,
    string $filearea, array $args,
    bool $forcedownload, array $options = []
) {
    if ($context->contextlevel !== CONTEXT_SYSTEM) {
        return false;
    }

    $allowedareas = ['logo', 'favicon', 'heroimage', 'loginbg'];
    if (!in_array($filearea, $allowedareas, true)) {
        return false;
    }

    $fs       = get_file_storage();
    $filename = array_pop($args);
    $file     = $fs->get_file($context->id, 'theme_learnhub', $filearea, 0, '/', $filename);

    if (!$file || $file->is_directory()) {
        send_file_not_found();
        return false;
    }

    send_stored_file($file, 604800, 0, $forcedownload, $options);
}


// =============================================================================
// HELPERS
// =============================================================================

/**
 * Simple hex colour darkening utility.
 * Avoids a full Sass dependency for runtime PHP colour manipulation.
 */
function theme_learnhub_darken_hex(string $hex, float $factor): string {
    $hex = ltrim($hex, '#');
    if (strlen($hex) === 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    $r = max(0, (int)(hexdec(substr($hex, 0, 2)) * (1 - $factor)));
    $g = max(0, (int)(hexdec(substr($hex, 2, 2)) * (1 - $factor)));
    $b = max(0, (int)(hexdec(substr($hex, 4, 2)) * (1 - $factor)));
    return sprintf('#%02x%02x%02x', $r, $g, $b);
}

function theme_learnhub_lighten_hex(string $hex, float $factor): string {
    $hex = ltrim($hex, '#');
    if (strlen($hex) === 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    $r = min(255, (int)(hexdec(substr($hex, 0, 2)) + (255 - hexdec(substr($hex, 0, 2))) * $factor));
    $g = min(255, (int)(hexdec(substr($hex, 2, 2)) + (255 - hexdec(substr($hex, 2, 2))) * $factor));
    $b = min(255, (int)(hexdec(substr($hex, 4, 2)) + (255 - hexdec(substr($hex, 4, 2))) * $factor));
    return sprintf('#%02x%02x%02x', $r, $g, $b);
}
