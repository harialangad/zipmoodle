# LearnHub — Moodle Theme
**IBS Software | Aviation & Travel Learning Platform**
Version 1.0.1 | Moodle 4.5+ | Child of Boost

---

## Quick Installation (Theme Selector)

### Method 1 — ZIP Upload (Recommended)
1. Download `theme_learnhub.zip`
2. In Moodle: **Site administration → Plugins → Install plugins**
3. Drag the ZIP into the upload area → **Install plugin from the ZIP file**
4. Click **Continue** through the upgrade confirmations
5. Navigate to **Site administration → Appearance → Themes → Theme selector**
6. Click **Use theme** next to **LearnHub**
7. Done — the theme is now active

### Method 2 — Server File Copy
```bash
# From your Moodle root
unzip theme_learnhub.zip -d /var/www/moodledata/theme/
# Or if unzipping gives a nested folder:
mv theme_learnhub /path/to/moodle/theme/learnhub

# Fix permissions (adjust www-data to your web user)
chown -R www-data:www-data /path/to/moodle/theme/learnhub

# Then in Moodle admin:
# Site administration → Notifications  (triggers plugin install)
# Site administration → Appearance → Themes → Theme selector → LearnHub
```

---

## Configuration

Navigate to **Site administration → Appearance → Themes → LearnHub → Settings**

### Branding tab
| Setting | Default | Description |
|---|---|---|
| Logo | — | PNG/SVG, max height 40px for navbar |
| Favicon | — | .ico or PNG 32×32px |
| Primary colour | `#0f4c81` | IBS Navy — applies to nav, buttons, links |
| Accent colour | `#ff6b35` | IBS Orange — CTAs, progress, badges |
| Brand name | `LearnHub` | Shown in navbar and footer |

### Hero & Dashboard tab
| Setting | Default | Description |
|---|---|---|
| Enable hero banner | ✓ | Full-width hero on My Dashboard |
| Hero subtitle | `IBS Software — Aviation & Travel Learning Platform` | Tagline under welcome message |
| Industry vertical | `Aviation` | Badge in hero; contextualises AI assistant |
| Hero background image | — | 1920×600px, displayed at low opacity |

### AI Assistant tab
| Setting | Default | Description |
|---|---|---|
| Enable AI Learning Assistant | ✓ | Shows the ✦ FAB on all pages |
| AI greeting message | *(personalised)* | Use `{firstname}` placeholder |
| AI system context | *(aviation-tuned)* | Sent with every AI request |

### Advanced tab
| Setting | Description |
|---|---|
| Login page background | 1920×1080px image |
| Footer content | HTML for the site footer |
| Custom CSS | Appended after all compiled styles |

---

## AI Assistant Setup

The AI Drawer requires **one** of the following to be configured:

### Option A — Moodle AI Subsystem (Recommended for Moodle 4.5+)
1. **Site administration → AI → AI providers**
2. Add an AI provider (OpenAI, Azure OpenAI, Ollama, or custom)
3. Enable the `generate_text` action
4. The LearnHub AI Drawer automatically uses this provider

### Option B — Direct API key (fallback)
1. Go to **LearnHub Settings → Advanced**
2. Add setting key `openai_api_key` via admin config
3. The AJAX endpoint (`ajax/ai_chat.php`) calls OpenAI directly

---

## After-Install Checklist

```
[ ] Theme active in Theme Selector
[ ] Purge all caches: Site admin → Development → Purge all caches
[ ] Set Primary and Accent colours to match your brand
[ ] Upload your organisation logo
[ ] Configure AI provider (Moodle AI Subsystem or API key)
[ ] Set industry vertical (Aviation / Cruise / Travel / Hospitality)
[ ] Test on mobile (375px) — theme is fully responsive
[ ] Run accessibility audit (WAVE or axe DevTools)
```

---

## File Structure

```
theme/learnhub/
├── version.php              Plugin version manifest
├── config.php               Theme config, layout map, SCSS pipeline
├── lib.php                  SCSS callbacks, page_init, renderer, helpers
├── settings.php             Admin Settings UI (4 tabs)
├── lang/en/theme_learnhub.php  All English strings
│
├── scss/
│   ├── pre.scss             Bootstrap variable overrides (pre-compile)
│   └── post.scss            All LearnHub rules (post-compile, ~600 lines)
│
├── layout/
│   ├── drawers.php          Main layout (dashboard/course/admin)
│   ├── login.php            Two-column login page
│   ├── columns1.php         Popup/print layout
│   ├── embedded.php         iFrame layout
│   ├── maintenance.php      Maintenance mode layout
│   └── secure.php           Secure quiz layout
│
├── templates/theme_learnhub/
│   ├── drawers.mustache     Full page shell with hero + AI FAB
│   ├── login.mustache       Brand-panel login template
│   ├── columns1.mustache    Single-column template
│   ├── embedded.mustache    Embedded template
│   ├── maintenance.mustache Maintenance template
│   └── secure.mustache      Secure template
│
├── amd/
│   ├── src/learnhub.js      AMD source (nav, progress ring, counters, AI drawer)
│   └── build/learnhub.min.js  Pre-compiled for production
│
├── ajax/ai_chat.php         AI Drawer server-side AJAX handler
│
├── classes/output/
│   └── core_renderer.php    Custom renderer (progress calc, AI greeting)
│
├── db/
│   ├── install.xml          learnhub_ai_log table schema
│   └── upgrade.php          Future schema upgrade hook
│
├── pix/
│   └── screenshot.png       Shown in Theme Selector UI
│
├── package.json             npm/Grunt build config
└── Gruntfile.js             AMD compilation task
```

---

## Rebuilding AMD (optional)

Only needed if you modify `amd/src/learnhub.js`:

```bash
cd theme/learnhub
npm install
npm run build       # or: npx grunt amd
```

Then purge Moodle caches.

---

## Requirements

| Requirement | Version |
|---|---|
| Moodle | 4.5+ |
| PHP | 8.1+ |
| Parent theme | Boost (bundled with Moodle) |
| Browser | Chrome 90+, Firefox 88+, Safari 14+, Edge 90+ |

---

## Support

Developed for IBS Software by the LearnHub team.
For issues, raise a ticket in the IBS internal issue tracker.
