<?php
// LearnHub — layout/login.php  (Moodle 4.5 safe)
defined('MOODLE_INTERNAL') || die();

$bodyattributes = $OUTPUT->body_attributes();

// Safe logo URL retrieval
$logourl = '';
$theme = theme_config::load('learnhub');
try {
    $logourl = $theme->setting_file_url('logo', 'logo');
} catch (Throwable $e) { /* no logo set */ }

// Login page background
$loginbgurl = '';
try {
    $loginbgurl = $theme->setting_file_url('loginbg', 'loginbg');
} catch (Throwable $e) { /* no bg image */ }

$templatecontext = [
    'output'        => $OUTPUT,
    'bodyattributes'=> $bodyattributes,
    'sitename'      => format_string($SITE->fullname, true,
                            ['context' => context_course::instance(SITEID), 'escape' => false]),
    'brandname'     => get_config('theme_learnhub', 'brandname') ?: 'LearnHub',
    'herosubtitle'  => get_config('theme_learnhub', 'herosubtitle')
                       ?: 'Aviation & Travel Learning Platform',
    'logincontent'  => $OUTPUT->main_content(),
    'logourl'       => $logourl,
    'loginbgurl'    => $loginbgurl,
    'footercontent' => format_text(
        get_config('theme_learnhub', 'footercontent')
            ?: '<p>&copy; ' . date('Y') . ' IBS Software. All rights reserved.</p>',
        FORMAT_HTML
    ),
];

echo $OUTPUT->render_from_template('theme_learnhub/login', $templatecontext);
