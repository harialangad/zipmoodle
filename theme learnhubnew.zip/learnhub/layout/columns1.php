<?php
// LearnHub — layout/columns1.php  (Moodle 4.5 safe)
defined('MOODLE_INTERNAL') || die();
$templatecontext = [
    'output'            => $OUTPUT,
    'bodyattributes'    => $OUTPUT->body_attributes(),
    'sitename'          => format_string($SITE->fullname, true,
                               ['context' => context_course::instance(SITEID), 'escape' => false]),
    'regionmaincontent' => $OUTPUT->main_content(),
    'sidepreblocks'     => $OUTPUT->blocks('side-pre'),
    'navbar'            => $OUTPUT->navbar(),
];
echo $OUTPUT->render_from_template('theme_learnhub/columns1', $templatecontext);
