<?php
// This file is part of Moodle - http://moodle.org/
//
// LearnHub — layout/drawers.php  (FIXED — Moodle 4.5+ compatible)
// Uses only confirmed core renderer methods.
// primary_nav() / navigation_xdrawer() removed — both are non-existent on core_renderer.
// Navigation is handled via core\navigation\output\primary (4.x API).

defined('MOODLE_INTERNAL') || die();

/** @var core_renderer $OUTPUT */
/** @var moodle_page   $PAGE   */
/** @var stdClass      $SITE   */
/** @var stdClass      $USER   */

// ── Core layout vars ──────────────────────────────────────────────────────────
$bodyattributes         = $OUTPUT->body_attributes();
$blockshtml             = $OUTPUT->blocks('side-pre');
$hasblocks              = strpos($blockshtml, 'data-block=') !== false;
$regionmainsettingsmenu = $OUTPUT->region_main_settings_menu();
$regionmaincontent      = $OUTPUT->main_content();
$pageheadingbutton      = $OUTPUT->page_heading_button();

// Add block button — only when editing is on
$addblockbutton = $PAGE->user_is_editing() ? $OUTPUT->addblockbutton('side-pre') : '';

// ── LearnHub settings ─────────────────────────────────────────────────────────
$enablehero       = get_config('theme_learnhub', 'enablehero');
$enableaidrawer   = get_config('theme_learnhub', 'enableaidrawer');
$brandname        = get_config('theme_learnhub', 'brandname')     ?: 'LearnHub';
$industryvertical = get_config('theme_learnhub', 'industryvertical') ?: 'Aviation';
$herosubtitle     = get_config('theme_learnhub', 'herosubtitle')
                    ?: 'IBS Software — Aviation & Travel Learning Platform';
$footerhtml       = get_config('theme_learnhub', 'footercontent')
                    ?: '<p>&copy; ' . date('Y') . ' IBS Software. All rights reserved.</p>';

$isdashboard  = ($PAGE->pagelayout === 'mydashboard');
$extraclasses = $isdashboard ? 'lh-page-dashboard' : '';

// ── Primary navigation — Moodle 4.x API ──────────────────────────────────────
// core\navigation\output\primary is the correct 4.x class.
// This replaces the non-existent primary_nav() call.
$primarymenu = [];
if (class_exists('\core\navigation\output\primary')) {
    $primary     = new \core\navigation\output\primary($PAGE);
    $renderer    = $PAGE->get_renderer('core');
    $primarymenu = $primary->export_for_template($renderer);
}

// ── Drawer open state (user preferences) ─────────────────────────────────────
$courseindexopen = !empty(get_user_preferences('drawer-open-index', true));
$blockdraweropen = !empty(get_user_preferences('drawer-open-block', false)) && $hasblocks;

// ── AI greeting ───────────────────────────────────────────────────────────────
$aigreeting = '';
if (!empty($enableaidrawer) && isloggedin() && !isguestuser()) {
    $raw = get_config('theme_learnhub', 'aigreeting')
           ?: "Hi {firstname}! I'm your LearnHub AI assistant. Ask me about your courses, compliance requirements, or upcoming activities.";
    $aigreeting = str_replace('{firstname}', $USER->firstname, $raw);
}

// ── Template context ──────────────────────────────────────────────────────────
$templatecontext = [
    // Moodle core vars
    'sitename'               => format_string($SITE->fullname, true,
                                    ['context' => context_course::instance(SITEID), 'escape' => false]),
    'output'                 => $OUTPUT,
    'bodyattributes'         => $bodyattributes,
    'sidepreblocks'          => $blockshtml,
    'hasblocks'              => $hasblocks,
    'regionmaincontent'      => $regionmaincontent,
    'regionmainsettingsmenu' => $regionmainsettingsmenu,
    'hasregionmainsettings'  => !empty($regionmainsettingsmenu),
    'pageheadingbutton'      => $pageheadingbutton,
    'addblockbutton'         => $addblockbutton,
    'courseindexopen'        => $courseindexopen,
    'blockdraweropen'        => $blockdraweropen,
    'flatnavigation'         => $PAGE->flatnav,
    // Primary nav components (4.x)
    'primarymoremenu'        => $primarymenu['moremenu']         ?? '',
    'mobileprimarynav'       => $primarymenu['mobileprimarynav'] ?? '',
    'usermenu'               => $primarymenu['usermenu']         ?? '',
    'langmenu'               => $primarymenu['langmenu']         ?? '',
    // LearnHub vars
    'brandname'              => $brandname,
    'industryvertical'       => $industryvertical,
    'herosubtitle'           => $herosubtitle,
    'isdashboard'            => $isdashboard,
    'enablehero'             => !empty($enablehero) && $isdashboard,
    'enableaidrawer'         => !empty($enableaidrawer),
    'isloggedin'             => isloggedin() && !isguestuser(),
    'userfullname'           => isloggedin() ? fullname($USER) : '',
    'userfirstname'          => isloggedin() ? $USER->firstname : '',
    'userid'                 => isloggedin() ? (int)$USER->id : 0,
    'sesskey'                => sesskey(),
    'aigreeting'             => $aigreeting,
    'aiserviceurl'           => (new moodle_url('/theme/learnhub/ajax/ai_chat.php'))->out(false),
    'footercontent'          => format_text($footerhtml, FORMAT_HTML),
    'extraclasses'           => $extraclasses,
];

echo $OUTPUT->render_from_template('theme_learnhub/drawers', $templatecontext);
