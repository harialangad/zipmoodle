<?php
// This file is part of Moodle - http://moodle.org/
//
// LearnHub — classes/output/core_renderer.php
// Extends Boost's core_renderer. Only overrides methods that actually exist.

namespace theme_learnhub\output;

defined('MOODLE_INTERNAL') || die();

use moodle_url;

// Boost renderer is the parent — it already extends core's renderer.
require_once($CFG->dirroot . '/theme/boost/classes/output/core_renderer.php');

class core_renderer extends \theme_boost\output\core_renderer {

    /**
     * Calculate overall completion % across all user's courses.
     * Used by the dashboard AMD module to set the progress ring.
     * Called from page_init via JS config.
     *
     * @param int $userid
     * @return float 0–100
     */
    public function get_overall_completion(int $userid): float {
        $courses = enrol_get_users_courses($userid, true, ['enablecompletion']);
        if (empty($courses)) {
            return 0.0;
        }

        $total = 0;
        $done  = 0;

        foreach ($courses as $course) {
            if (empty($course->enablecompletion)) {
                continue;
            }
            try {
                $info = new \completion_info($course);
                if (!$info->is_enabled()) {
                    continue;
                }
                foreach ($info->get_activities() as $cm) {
                    $total++;
                    $data = $info->get_data($cm, false, $userid);
                    if (in_array($data->completionstate,
                        [COMPLETION_COMPLETE, COMPLETION_COMPLETE_PASS], true)) {
                        $done++;
                    }
                }
            } catch (\Throwable $e) {
                continue;
            }
        }

        return $total > 0 ? round(($done / $total) * 100, 1) : 0.0;
    }

    /**
     * Return the AI greeting string with firstname substituted.
     *
     * @return string
     */
    public function get_ai_greeting(): string {
        global $USER;
        if (!isloggedin() || isguestuser()) {
            return '';
        }
        $tpl = get_config('theme_learnhub', 'aigreeting')
               ?: "Hi {firstname}! I'm your LearnHub AI assistant.";
        return str_replace('{firstname}', $USER->firstname, $tpl);
    }
}
